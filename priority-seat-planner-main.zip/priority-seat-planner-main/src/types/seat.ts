
export type StudentYear = "first" | "second" | "third" | "final";

export type Student = {
  id: string;
  name: string;
  email?: string; // Made optional since we're removing it from the form
  year: StudentYear;
  registrationNumber: string;
  allocated: boolean;
  seatNumber?: string;
};

export type Seat = {
  id: string;
  number: string;
  row: number;
  column: number;
  allocated: boolean;
  student?: Student;
  yearAllocated?: StudentYear;
};

export type YearQuota = {
  year: StudentYear;
  totalSeats: number;
  allocatedSeats: number;
  startRow: number;
  endRow: number;
};


import { Student, Seat, YearQuota, StudentYear } from '@/types/seat';
import { toast } from '@/components/ui/sonner';

export const allocateSeats = (
  students: Student[],
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>,
  yearQuotas: YearQuota[],
  setYearQuotas: React.Dispatch<React.SetStateAction<YearQuota[]>>,
  setAllocationDone: React.Dispatch<React.SetStateAction<boolean>>
) => {
  return () => {
    if (students.length === 0) {
      toast.error("No students registered");
      return;
    }

    // Create a copy of students sorted by priority (final year first)
    const priorityOrder: StudentYear[] = ['final', 'third', 'second', 'first'];
    const sortedStudents = [...students].sort((a, b) => 
      priorityOrder.indexOf(a.year) - priorityOrder.indexOf(b.year)
    );
    
    // Create a copy of the year quotas
    const updatedQuotas = [...yearQuotas];
    
    // Mark all students as allocated, without assigning specific seats yet
    const updatedStudents = sortedStudents.map(student => ({
      ...student,
      allocated: true
    }));
    
    // Update the year quotas to track how many students of each year were allocated
    updatedQuotas.forEach(quota => {
      const studentsInYear = updatedStudents.filter(s => s.year === quota.year).length;
      quota.allocatedSeats = Math.min(studentsInYear, quota.totalSeats);
    });
    
    // Update state
    setYearQuotas(updatedQuotas);
    setStudents(updatedStudents);
    setAllocationDone(true);
    
    toast.success(`Students are now eligible to select their seats`);
  };
};

export const selectSeat = (
  seatId: string,
  studentId: string,
  seats: Seat[],
  students: Student[],
  setSeats: React.Dispatch<React.SetStateAction<Seat[]>>,
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>,
  yearQuotas: YearQuota[]
) => {
  // Find the seat and student
  const seat = seats.find(s => s.id === seatId);
  const student = students.find(s => s.id === studentId);
  
  if (!seat || !student) {
    toast.error("Seat or student not found");
    return;
  }
  
  if (seat.student) {
    toast.error("This seat is already taken by another student");
    return;
  }
  
  if (student.seatNumber) {
    toast.error("You've already selected a seat");
    return;
  }
  
  // Check if the seat is in the rows allocated for this student's year
  const yearQuota = yearQuotas.find(q => q.year === student.year);
  if (!yearQuota || seat.row < yearQuota.startRow || seat.row > yearQuota.endRow) {
    toast.error("This seat is not in your allocated year rows");
    return;
  }
  
  // Update the seat
  const updatedSeats = seats.map(s => 
    s.id === seatId 
      ? { ...s, student: student, allocated: true } 
      : s
  );
  
  // Update the student
  const updatedStudents = students.map(s => 
    s.id === studentId 
      ? { ...s, seatNumber: seat.number } 
      : s
  );
  
  setSeats(updatedSeats);
  setStudents(updatedStudents);
  
  toast.success(`Seat ${seat.number} assigned to ${student.name}`);
};

export const resetAllocation = (
  seats: Seat[],
  students: Student[],
  yearQuotas: YearQuota[],
  setSeats: React.Dispatch<React.SetStateAction<Seat[]>>,
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>,
  setYearQuotas: React.Dispatch<React.SetStateAction<YearQuota[]>>,
  setAllocationDone: React.Dispatch<React.SetStateAction<boolean>>
) => {
  // Reset all seats
  const resetSeats = seats.map(seat => ({
    ...seat,
    allocated: false,
    student: undefined,
    yearAllocated: undefined
  }));
  
  // Reset all students
  const resetStudents = students.map(student => ({
    ...student,
    allocated: false,
    seatNumber: undefined
  }));
  
  // Reset year quotas
  const resetQuotas = yearQuotas.map(quota => ({
    ...quota,
    allocatedSeats: 0
  }));
  
  setSeats(resetSeats);
  setStudents(resetStudents);
  setYearQuotas(resetQuotas);
  setAllocationDone(false);
  
  toast.success("All allocations have been reset");
};


import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Student, Seat, YearQuota } from '@/types/seat';
import { toast } from '@/components/ui/sonner';
import { SeatContextType } from './types';
import { defaultYearQuotas } from './seatConstants';
import { initializeSeats } from './seatInitialization';
import { registerStudent } from './studentManagement';
import { allocateSeats as allocateSeatsFunction, selectSeat as selectSeatFunction, resetAllocation as resetAllocationFunction } from './seatAllocation';

const SeatContext = createContext<SeatContextType | undefined>(undefined);

export const SeatProvider = ({ children }: { children: ReactNode }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [seats, setSeats] = useState<Seat[]>([]);
  const [yearQuotas, setYearQuotas] = useState<YearQuota[]>(defaultYearQuotas);
  const [registrationOpen, setRegistrationOpen] = useState<boolean>(true);
  const [allocationDone, setAllocationDone] = useState<boolean>(false);
  
  // Calculate the total number of seats
  const totalSeats = yearQuotas.reduce((acc, quota) => acc + quota.totalSeats, 0);
  
  // Calculate the remaining seats
  const remainingSeats = totalSeats - students.length;

  // Initialize seats when the component mounts
  useEffect(() => {
    setSeats(initializeSeats());
  }, []);

  // Create context functions with all dependencies
  const registerStudentHandler = registerStudent(students, setStudents, totalSeats, yearQuotas);
  
  const allocateSeatsHandler = allocateSeatsFunction(
    students,
    setStudents,
    yearQuotas,
    setYearQuotas,
    setAllocationDone
  );
  
  const selectSeatHandler = (seatId: string, studentId: string) => {
    selectSeatFunction(
      seatId,
      studentId,
      seats,
      students,
      setSeats,
      setStudents,
      yearQuotas
    );
  };

  const toggleRegistration = () => {
    setRegistrationOpen(prev => !prev);
    toast(registrationOpen ? "Registration closed" : "Registration open");
  };

  const resetAllocationHandler = () => {
    resetAllocationFunction(
      seats,
      students,
      yearQuotas,
      setSeats,
      setStudents,
      setYearQuotas,
      setAllocationDone
    );
  };

  return (
    <SeatContext.Provider value={{
      students,
      seats,
      yearQuotas,
      registrationOpen,
      allocationDone,
      totalSeats,
      remainingSeats,
      registerStudent: registerStudentHandler,
      allocateSeats: allocateSeatsHandler,
      selectSeat: selectSeatHandler,
      toggleRegistration,
      resetAllocation: resetAllocationHandler
    }}>
      {children}
    </SeatContext.Provider>
  );
};

export const useSeatContext = () => {
  const context = useContext(SeatContext);
  if (context === undefined) {
    throw new Error('useSeatContext must be used within a SeatProvider');
  }
  return context;
};

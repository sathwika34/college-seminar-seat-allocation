
import { YearQuota } from '@/types/seat';

export const defaultYearQuotas: YearQuota[] = [
  { year: 'final', totalSeats: 40, allocatedSeats: 0, startRow: 1, endRow: 4 },
  { year: 'third', totalSeats: 30, allocatedSeats: 0, startRow: 5, endRow: 7 },
  { year: 'second', totalSeats: 20, allocatedSeats: 0, startRow: 8, endRow: 9 },
  { year: 'first', totalSeats: 10, allocatedSeats: 0, startRow: 10, endRow: 10 },
];

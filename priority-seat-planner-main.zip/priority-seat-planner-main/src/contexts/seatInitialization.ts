
import { Seat } from '@/types/seat';

export const initializeSeats = (): Seat[] => {
  const initialSeats: Seat[] = [];
  const seatsPerRow = 10; // 10 seats per row
  
  // Create 10 rows with 10 seats each (100 seats total)
  for (let row = 1; row <= 10; row++) {
    for (let col = 1; col <= seatsPerRow; col++) {
      const seatNumber = (row - 1) * seatsPerRow + col;
      initialSeats.push({
        id: `seat-${seatNumber}`,
        number: `S${seatNumber.toString().padStart(2, '0')}`,
        row,
        column: col,
        allocated: false
      });
    }
  }
  
  return initialSeats;
};

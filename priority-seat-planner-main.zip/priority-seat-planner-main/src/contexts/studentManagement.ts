
import { Student, StudentYear } from '@/types/seat';
import { toast } from '@/components/ui/sonner';

export const registerStudent = (
  students: Student[],
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>,
  totalSeats: number,
  yearQuotas: { year: StudentYear; totalSeats: number }[]
) => {
  return (student: Omit<Student, 'id' | 'allocated' | 'seatNumber' | 'email'>) => {
    // Check for duplicate registration
    const isDuplicate = students.some(
      s => s.registrationNumber === student.registrationNumber
    );
    
    if (isDuplicate) {
      toast.error("A student with this registration number already exists");
      return;
    }
    
    // Check if seats are still available
    if (students.length >= totalSeats) {
      toast.error("No more seats available for registration");
      return;
    }

    // Check if year quota is available
    const yearQuota = yearQuotas.find(q => q.year === student.year);
    const studentsInYear = students.filter(s => s.year === student.year).length;
    
    if (yearQuota && studentsInYear >= yearQuota.totalSeats) {
      toast.error(`No more seats available for ${student.year} year students`);
      return;
    }
    
    const newStudent: Student = {
      ...student,
      id: `student-${Date.now()}`,
      allocated: false,
    };
    
    setStudents(prev => [...prev, newStudent]);
    toast.success(`${student.name} has been registered successfully`);
  };
};

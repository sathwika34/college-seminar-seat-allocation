
import { Student, Seat, YearQuota, StudentYear } from '@/types/seat';

// Context type definitions
export interface SeatContextType {
  students: Student[];
  seats: Seat[];
  yearQuotas: YearQuota[];
  registrationOpen: boolean;
  allocationDone: boolean;
  totalSeats: number;
  remainingSeats: number;
  
  // Actions
  registerStudent: (student: Omit<Student, 'id' | 'allocated' | 'seatNumber' | 'email'>) => void;
  allocateSeats: () => void;
  selectSeat: (seatId: string, studentId: string) => void;
  toggleRegistration: () => void;
  resetAllocation: () => void;
}


import React from 'react';
import { useSeatContext } from '@/contexts/SeatContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

const AdminPanel = () => {
  const { 
    students, 
    yearQuotas, 
    allocateSeats, 
    toggleRegistration, 
    registrationOpen, 
    allocationDone,
    resetAllocation,
    totalSeats,
    remainingSeats
  } = useSeatContext();

  const yearCounts = {
    first: students.filter(s => s.year === 'first').length,
    second: students.filter(s => s.year === 'second').length,
    third: students.filter(s => s.year === 'third').length,
    final: students.filter(s => s.year === 'final').length,
  };
  
  const allocatedCounts = {
    first: students.filter(s => s.year === 'first' && s.allocated).length,
    second: students.filter(s => s.year === 'second' && s.allocated).length,
    third: students.filter(s => s.year === 'third' && s.allocated).length,
    final: students.filter(s => s.year === 'final' && s.allocated).length,
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Admin Control Panel</CardTitle>
        <CardDescription>Manage seat allocation for the seminar</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Seminar Status</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-muted rounded p-3">
                <div className="text-sm text-muted-foreground">Total Seats</div>
                <div className="text-2xl font-bold">{totalSeats}</div>
              </div>
              <div className="bg-muted rounded p-3">
                <div className="text-sm text-muted-foreground">Remaining</div>
                <div className="text-2xl font-bold">{remainingSeats}</div>
              </div>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Registration Status</h3>
            <div className="flex items-center justify-between">
              <div>
                <Badge variant={registrationOpen ? "outline" : "secondary"}>
                  {registrationOpen ? "Open" : "Closed"}
                </Badge>
                <span className="ml-2">
                  Total Registered: {students.length}
                </span>
              </div>
              <Button 
                variant={registrationOpen ? "destructive" : "default"}
                onClick={toggleRegistration}
              >
                {registrationOpen ? "Close Registration" : "Open Registration"}
              </Button>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Year-wise Registration</h3>
            <div className="grid grid-cols-4 gap-2 sm:gap-4">
              <div className="bg-muted rounded p-2">
                <Badge className="bg-year-final text-white">Final Year</Badge>
                <div className="mt-1 text-2xl font-bold">{yearCounts.final}</div>
                <div className="text-xs text-muted-foreground">
                  {allocatedCounts.final} allocated
                </div>
              </div>
              <div className="bg-muted rounded p-2">
                <Badge className="bg-year-third text-white">Third Year</Badge>
                <div className="mt-1 text-2xl font-bold">{yearCounts.third}</div>
                <div className="text-xs text-muted-foreground">
                  {allocatedCounts.third} allocated
                </div>
              </div>
              <div className="bg-muted rounded p-2">
                <Badge className="bg-year-second text-white">Second Year</Badge>
                <div className="mt-1 text-2xl font-bold">{yearCounts.second}</div>
                <div className="text-xs text-muted-foreground">
                  {allocatedCounts.second} allocated
                </div>
              </div>
              <div className="bg-muted rounded p-2">
                <Badge className="bg-year-first text-white">First Year</Badge>
                <div className="mt-1 text-2xl font-bold">{yearCounts.first}</div>
                <div className="text-xs text-muted-foreground">
                  {allocatedCounts.first} allocated
                </div>
              </div>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Seat Allocation</h3>
            <div className="grid gap-2">
              <div className="grid grid-cols-4 gap-2">
                {yearQuotas.map((quota) => (
                  <div key={quota.year} className="bg-muted rounded p-2">
                    <div className="text-sm capitalize">{quota.year} Year Quota</div>
                    <div className="text-xl font-bold">
                      {quota.allocatedSeats}/{quota.totalSeats}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="flex space-x-2">
                <Button 
                  className="flex-1"
                  onClick={allocateSeats}
                  disabled={allocationDone || students.length === 0}
                >
                  Allocate Seats
                </Button>
                <Button 
                  className="flex-1"
                  variant="outline"
                  onClick={resetAllocation}
                  disabled={!allocationDone}
                >
                  Reset Allocation
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AdminPanel;

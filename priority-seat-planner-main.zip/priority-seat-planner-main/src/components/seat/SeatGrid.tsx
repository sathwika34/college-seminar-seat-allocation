
import { Button } from '@/components/ui/button';
import { useSeatContext } from '@/contexts/SeatContext';
import { cn } from '@/lib/utils';
import { Seat, StudentYear } from '@/types/seat';
import { CheckCircle } from 'lucide-react';

interface SeatGridProps {
  selectedStudentId: string;
  setSelectedStudentId: (id: string) => void;
}

const SeatGrid = ({ selectedStudentId, setSelectedStudentId }: SeatGridProps) => {
  const { seats, students, selectSeat, yearQuotas } = useSeatContext();
  
  const selectedStudent = students.find(s => s.id === selectedStudentId);

  // Group seats by row
  const seatsByRow = seats.reduce((acc, seat) => {
    if (!acc[seat.row]) {
      acc[seat.row] = [];
    }
    acc[seat.row].push(seat);
    return acc;
  }, {} as Record<number, Seat[]>);

  // Get year for a specific row
  const getYearForRow = (row: number): StudentYear | undefined => {
    const yearQuota = yearQuotas.find(quota => row >= quota.startRow && row <= quota.endRow);
    return yearQuota?.year;
  };

  // Check if a seat is in the rows allocated for the student's year
  const isSeatInStudentYearRows = (seat: Seat, studentYear?: StudentYear): boolean => {
    if (!studentYear) return false;
    
    const yearQuota = yearQuotas.find(quota => quota.year === studentYear);
    if (!yearQuota) return false;
    
    return seat.row >= yearQuota.startRow && seat.row <= yearQuota.endRow;
  };

  return (
    <div 
      className="border-2 border-indigo-100 p-6 rounded-lg shadow-md bg-white/60 backdrop-blur-md"
      style={{
        backgroundImage: "url('https://img.freepik.com/free-vector/abstract-white-shapes-background_79603-1362.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundBlendMode: "soft-light"
      }}
    >
      <div className="text-center mb-6 border-b pb-2 text-lg font-semibold text-indigo-800">
        <div className="relative pb-2">
          <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-indigo-200 to-transparent bottom-0"></div>
          STAGE
        </div>
      </div>
      
      <div className="space-y-3">
        {Object.entries(seatsByRow).map(([rowNum, rowSeats]) => {
          const rowNumber = parseInt(rowNum);
          const year = getYearForRow(rowNumber);
          
          return (
            <div key={`row-${rowNum}`} className="flex justify-center gap-1.5">
              <div className="w-8 text-xs flex items-center justify-center font-medium text-indigo-600 bg-indigo-50/50 rounded-md">
                R{rowNum}
              </div>
              {rowSeats.sort((a, b) => a.column - b.column).map((seat) => {
                // Check if this seat is available and in student's year rows
                const isInStudentYearRows = selectedStudent && isSeatInStudentYearRows(seat, selectedStudent.year);
                const isSeatAvailable = !seat.student;
                const isSeatSelected = seat.student !== undefined;
                
                return (
                  <Button
                    key={seat.id}
                    variant={isSeatSelected ? "secondary" : "outline"}
                    className={cn(
                      "h-10 w-10 p-0 text-xs relative transition-all border shadow-sm",
                      isSeatSelected 
                        ? "animate-pulse-seat bg-opacity-90" 
                        : isSeatInStudentYearRows && isSeatAvailable 
                          ? "bg-opacity-70 hover:bg-opacity-100 border-dashed hover:scale-105 transition-transform duration-200" 
                          : "",
                      seat.student ? "bg-slate-100" : `hover:bg-year-${year} hover:text-white`
                    )}
                    style={{
                      backgroundColor: isSeatSelected ? "#f8fafc" : `var(--year-${year})`,
                      opacity: isSeatSelected ? 1 : (isSeatAvailable && isInStudentYearRows ? 0.8 : 0.6),
                    }}
                    disabled={!selectedStudentId || !isSeatAvailable || !isInStudentYearRows}
                    onClick={() => {
                      if (selectedStudentId && isSeatAvailable && isInStudentYearRows) {
                        selectSeat(seat.id, selectedStudentId);
                        setSelectedStudentId("");
                      }
                    }}
                    title={seat.student ? `Taken by ${seat.student.name}` : 
                          isInStudentYearRows ? `Available for you` :
                          `${year} Year`
                    }
                  >
                    {isSeatSelected ? (
                      <>
                        <span className="sr-only">Seat {seat.column}</span>
                        <CheckCircle className="h-5 w-5 text-green-500 absolute -top-1 -right-1 bg-white rounded-full shadow-sm" />
                        {seat.column}
                      </>
                    ) : (
                      seat.column
                    )}
                  </Button>
                );
              })}
            </div>
          );
        })}
      </div>
      <div className="text-xs text-center text-muted-foreground mt-4 bg-white/70 py-2 px-4 rounded-md shadow-sm backdrop-blur-sm">
        <span className="flex items-center justify-center gap-1">
          <CheckCircle className="h-3 w-3 text-green-500" />
          <span>Selected seats are marked with a green checkmark</span>
        </span>
      </div>
    </div>
  );
};

export default SeatGrid;

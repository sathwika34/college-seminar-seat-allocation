
import React from 'react';

const SeatLegend = () => {
  return (
    <div className="mb-3 flex flex-wrap gap-3 justify-center p-3 rounded-lg bg-white/70 backdrop-blur-sm shadow-sm">
      <div className="flex items-center">
        <span className="h-4 w-4 rounded-full bg-year-final mr-1.5 shadow-sm"></span>
        <span className="text-xs font-medium">Final Year (Rows 1-4)</span>
      </div>
      <div className="flex items-center">
        <span className="h-4 w-4 rounded-full bg-year-third mr-1.5 shadow-sm"></span>
        <span className="text-xs font-medium">Third Year (Rows 5-7)</span>
      </div>
      <div className="flex items-center">
        <span className="h-4 w-4 rounded-full bg-year-second mr-1.5 shadow-sm"></span>
        <span className="text-xs font-medium">Second Year (Rows 8-9)</span>
      </div>
      <div className="flex items-center">
        <span className="h-4 w-4 rounded-full bg-year-first mr-1.5 shadow-sm"></span>
        <span className="text-xs font-medium">First Year (Row 10)</span>
      </div>
    </div>
  );
};

export default SeatLegend;

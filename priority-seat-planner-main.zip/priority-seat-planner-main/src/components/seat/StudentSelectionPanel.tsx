
import { useState } from 'react';
import { useSeatContext } from '@/contexts/SeatContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Student } from '@/types/seat';
import { Search } from 'lucide-react';

interface StudentSelectionPanelProps {
  selectedStudentId: string;
  setSelectedStudentId: (id: string) => void;
}

const StudentSelectionPanel = ({ 
  selectedStudentId, 
  setSelectedStudentId 
}: StudentSelectionPanelProps) => {
  const { students } = useSeatContext();
  const [searchTerm, setSearchTerm] = useState<string>("");

  const eligibleStudents = students.filter(student => 
    student.allocated && !student.seatNumber
  );
  
  const filteredStudents = eligibleStudents.filter(student => 
    student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const selectedStudent = students.find(s => s.id === selectedStudentId);

  return (
    <div className="space-y-4 bg-white/70 p-4 rounded-lg shadow-md backdrop-blur-sm">
      <div>
        <Label htmlFor="search" className="font-medium text-indigo-800">Find yourself</Label>
        <div className="relative">
          <Input
            id="search"
            placeholder="Search by name or reg. number"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 bg-white/90 border-indigo-100 focus:border-indigo-300"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
      </div>
      
      <div className="h-[300px] overflow-y-auto border rounded-lg shadow-inner bg-white/90 p-3">
        {filteredStudents.length > 0 ? (
          filteredStudents.map(student => (
            <div 
              key={student.id}
              className={cn(
                "p-3 rounded-md mb-2 cursor-pointer transition-all",
                selectedStudentId === student.id 
                  ? "bg-gradient-to-r from-indigo-100 to-blue-100 text-indigo-900 shadow-md" 
                  : "hover:bg-blue-50 border border-gray-100"
              )}
              onClick={() => setSelectedStudentId(student.id)}
            >
              <div className="font-medium">{student.name}</div>
              <div className="text-sm flex justify-between items-center">
                <span>{student.registrationNumber}</span>
                <Badge className={`bg-year-${student.year} text-white shadow-sm`}>
                  {student.year.charAt(0).toUpperCase() + student.year.slice(1)} Year
                </Badge>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            {searchTerm 
              ? "No matching students found" 
              : "No students available for seat selection"}
          </div>
        )}
      </div>
      
      {selectedStudent && (
        <div className="p-4 rounded-md bg-gradient-to-r from-blue-50 to-indigo-50 shadow-sm border border-blue-100">
          <div className="font-medium text-indigo-800">Selected: {selectedStudent.name}</div>
          <div className="text-sm mt-1 flex items-center gap-2">
            Please select any available seat from {selectedStudent.year} year rows
            <span className={`inline-block h-4 w-4 rounded-full bg-year-${selectedStudent.year}`}></span>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentSelectionPanel;

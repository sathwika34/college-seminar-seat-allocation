
import { useState } from 'react';
import { useSeatContext } from '@/contexts/SeatContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { StudentYear } from '@/types/seat';

const RegistrationForm = () => {
  const { registerStudent, registrationOpen } = useSeatContext();
  
  const [name, setName] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [year, setYear] = useState<StudentYear>('first');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !registrationNumber) {
      return;
    }
    
    registerStudent({
      name,
      registrationNumber,
      year,
    });
    
    // Reset form
    setName('');
    setRegistrationNumber('');
    setYear('first');
  };
  
  if (!registrationOpen) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Registration Closed</CardTitle>
          <CardDescription>
            Registration for seminar seats is currently closed.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Student Registration</CardTitle>
        <CardDescription>
          Register for a seat in the seminar hall.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Full Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="John Doe"
              required
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="registration">Registration Number</Label>
            <Input
              id="registration"
              value={registrationNumber}
              onChange={(e) => setRegistrationNumber(e.target.value)}
              placeholder="REG12345"
              required
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="year">Year of Study</Label>
            <Select
              value={year}
              onValueChange={(value) => setYear(value as StudentYear)}
            >
              <SelectTrigger id="year">
                <SelectValue placeholder="Select year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="first">First Year</SelectItem>
                <SelectItem value="second">Second Year</SelectItem>
                <SelectItem value="third">Third Year</SelectItem>
                <SelectItem value="final">Final Year</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button type="submit" className="w-full">Register</Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default RegistrationForm;


import { Button } from '@/components/ui/button';
import { useSeatContext } from '@/contexts/SeatContext';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';

const ApplicationHeader = () => {
  const { totalSeats, remainingSeats } = useSeatContext();
  
  return (
    <div className="flex flex-col md:flex-row justify-between items-center p-4 border-b">
      <div className="text-2xl font-bold text-primary">
        College Seminar Seat Allocation
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="text-sm">
          <span className="text-muted-foreground">Available Seats: </span>
          <span className={`font-medium ${remainingSeats < 10 ? 'text-red-500' : remainingSeats < 20 ? 'text-amber-500' : 'text-green-500'}`}>
            {remainingSeats}
          </span>
          <span className="text-muted-foreground"> of </span>
          <span className="font-medium">{totalSeats}</span>
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">Actions</Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => window.print()}>
              Print Report
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default ApplicationHeader;

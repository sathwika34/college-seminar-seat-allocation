
import { useState } from 'react';
import { useSeatContext } from '@/contexts/SeatContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { StudentYear } from '@/types/seat';
import { Check } from 'lucide-react';

const StudentList = () => {
  const { students } = useSeatContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | StudentYear>('all');
  
  const filteredStudents = students.filter(student => {
    // Filter by tab
    if (activeTab !== 'all' && student.year !== activeTab) {
      return false;
    }
    
    // Filter by search (removed email)
    if (searchTerm) {
      return (
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    return true;
  });
  
  const getBadgeColor = (year: StudentYear) => {
    const colors: Record<StudentYear, string> = {
      first: 'bg-year-first',
      second: 'bg-year-second',
      third: 'bg-year-third',
      final: 'bg-year-final',
    };
    
    return colors[year];
  };

  return (
    <Card className="bg-gradient-to-br from-white to-blue-50">
      <CardHeader className="border-b">
        <CardTitle className="text-indigo-800">Registered Students</CardTitle>
        <CardDescription>
          {students.length} students registered
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 pt-4">
        <div className="space-y-4">
          <div>
            <Label htmlFor="search">Search Students</Label>
            <Input
              id="search"
              placeholder="Search by name or registration number"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
            <TabsList className="grid grid-cols-5">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="first">1st Year</TabsTrigger>
              <TabsTrigger value="second">2nd Year</TabsTrigger>
              <TabsTrigger value="third">3rd Year</TabsTrigger>
              <TabsTrigger value="final">Final Year</TabsTrigger>
            </TabsList>
          </Tabs>
          
          <div className="border rounded-md shadow-sm overflow-hidden">
            <div className="grid grid-cols-8 bg-indigo-50 p-2 font-medium text-sm">
              <div className="col-span-3">Name</div>
              <div className="col-span-2">Registration</div>
              <div className="col-span-2">Year</div>
              <div className="col-span-1">Seat</div>
            </div>
            
            <div className="divide-y max-h-[400px] overflow-y-auto">
              {filteredStudents.length > 0 ? (
                filteredStudents.map(student => (
                  <div key={student.id} className="grid grid-cols-8 p-2 text-sm hover:bg-slate-50">
                    <div className="col-span-3">{student.name}</div>
                    <div className="col-span-2">{student.registrationNumber}</div>
                    <div className="col-span-2">
                      <Badge className={getBadgeColor(student.year)}>
                        {student.year.charAt(0).toUpperCase() + student.year.slice(1)}
                      </Badge>
                    </div>
                    <div className="col-span-1 flex items-center">
                      {student.seatNumber ? (
                        <div className="flex items-center gap-1">
                          <span className="text-xs">{student.seatNumber}</span>
                          <span className="h-4 w-4 rounded-full bg-green-500 flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </span>
                        </div>
                      ) : (
                        student.allocated ? "Allocated" : "-"
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-muted-foreground">
                  No students found
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StudentList;

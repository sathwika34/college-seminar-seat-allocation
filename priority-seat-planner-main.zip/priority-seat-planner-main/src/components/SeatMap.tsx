
import { useState } from 'react';
import { useSeatContext } from '@/contexts/SeatContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import StudentSelectionPanel from './seat/StudentSelectionPanel';
import SeatGrid from './seat/SeatGrid';
import SeatLegend from './seat/SeatLegend';

const SeatMap = () => {
  const { allocationDone } = useSeatContext();
  const [selectedStudentId, setSelectedStudentId] = useState<string>("");

  if (!allocationDone) {
    return (
      <Card className="bg-gradient-to-br from-white to-blue-50 shadow-lg">
        <CardHeader>
          <CardTitle className="text-indigo-800">Seat Selection</CardTitle>
          <CardDescription>
            Seats will be available after allocation is completed.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <div 
      className="relative rounded-lg overflow-hidden border shadow-xl"
      style={{
        backgroundImage: "url('https://img.freepik.com/free-photo/empty-conference-hall-with-chairs_1232-3541.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="absolute inset-0 bg-white/85 backdrop-blur-sm"></div>
      <Card className="relative bg-transparent border-none shadow-none">
        <CardHeader className="border-b bg-gradient-to-r from-blue-50/80 to-purple-50/80 backdrop-blur-sm">
          <CardTitle className="text-indigo-800">College Seminar Hall Seating</CardTitle>
          <CardDescription>
            Choose any available seat from your year's allocated rows
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <StudentSelectionPanel 
              selectedStudentId={selectedStudentId} 
              setSelectedStudentId={setSelectedStudentId} 
            />
            
            <div className="space-y-4">
              <SeatLegend />
              <SeatGrid 
                selectedStudentId={selectedStudentId} 
                setSelectedStudentId={setSelectedStudentId} 
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SeatMap;


import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { SeatProvider } from '@/contexts/SeatContext';
import ApplicationHeader from '@/components/ApplicationHeader';
import RegistrationForm from '@/components/RegistrationForm';
import AdminPanel from '@/components/AdminPanel';
import SeatMap from '@/components/SeatMap';
import StudentList from '@/components/StudentList';

const Index = () => {
  return (
    <SeatProvider>
      <div 
        className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-blue-50"
        style={{
          backgroundImage: "url('https://img.freepik.com/free-vector/white-elegant-texture-background_23-2148431731.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundAttachment: "fixed",
          backgroundBlendMode: "overlay"
        }}
      >
        <ApplicationHeader />
        
        <div className="container py-8">
          <Tabs defaultValue="register" className="space-y-6">
            <TabsList className="grid grid-cols-4 shadow-md bg-white/80 backdrop-blur-sm">
              <TabsTrigger value="register">Register</TabsTrigger>
              <TabsTrigger value="admin">Admin Panel</TabsTrigger>
              <TabsTrigger value="select">Seat Selection</TabsTrigger>
              <TabsTrigger value="list">Student List</TabsTrigger>
            </TabsList>
            
            <div className="bg-white/90 backdrop-blur-sm rounded-lg p-6 shadow-lg border border-slate-100">
              <TabsContent value="register" className="mt-0">
                <RegistrationForm />
              </TabsContent>
              
              <TabsContent value="admin" className="mt-0">
                <AdminPanel />
              </TabsContent>
              
              <TabsContent value="select" className="mt-0">
                <SeatMap />
              </TabsContent>
              
              <TabsContent value="list" className="mt-0">
                <StudentList />
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </SeatProvider>
  );
};

export default Index;
